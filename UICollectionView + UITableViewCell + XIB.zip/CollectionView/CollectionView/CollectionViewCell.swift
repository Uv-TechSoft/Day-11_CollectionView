//
//  CollectionViewCell.swift
//  CollectionView
//
//  Created by Yogesh Patel on 02/11/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
}
